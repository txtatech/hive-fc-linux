# chess-in-x8086-assembly
The chess board is displayed as a background so your assembler need to have black-colered
background or you will have to display it in another page so you can use tasm not dosbox

the game will be alwayes waiting for an input once for white (yellow) and once for black (light cyan)
and don't forget to enter the char (piece) carefully as it is the char will be displayed later

be carful with your input you can't undo

rows and columns starts with 0 and ends with 7
you might face some problems if you enterd more than 1 digit "although you can"

you might face a problem when you enter a char but it just get deleted without moving or vise versa i
don't know why this happen sometimes but you can just play a turn with empyt places 


Enjoy ....
